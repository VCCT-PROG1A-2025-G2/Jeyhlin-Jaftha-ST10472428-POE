/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jeyhl
 */
public class Login {
    private static String savedUsername;
    private static String savedPassword;
    private static String savedFirstName = "Kyle";
    private static String savedLastName = "Smith";

    // 1. User validation
    public static boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // 2. Password complexity validation 
    public static boolean checkPasswordComplexity(String password) {
        boolean length = password.length() >= 8;
        boolean upper = password.matches(".*[A-Z].*");
        boolean number = password.matches(".*\\d.*");
        boolean special = password.matches(".*\\W.*");

        return length && upper && number && special;
    }

    // 3. Cell phone number validation (for South African numbers)
    public static boolean checkCellPhoneNumber(String phone) {
        return phone.matches("^\\+27\\d{9}$");  // South African phone number format (+27 followed by 9 digits)
    }

    // 4. Register user
    public static String registerUser(String username, String password, String phone) {
        boolean usernameValid = checkUserName(username);
        boolean passwordValid = checkPasswordComplexity(password);
        boolean phoneValid = checkCellPhoneNumber(phone);

        if (!usernameValid) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }

        if (!passwordValid) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }

        if (!phoneValid) {
            return "Cell number is incorrectly formatted or does not contain an international code, please correct the number and try again.";
        }

        savedUsername = username;
        savedPassword = password;
        return "Account successfully registered.";
    }

    // 5. Login
    public static boolean loginUser(String username, String password) {
        return savedUsername != null && savedPassword != null &&
               savedUsername.equals(username) && savedPassword.equals(password);
    }

    // 6. Login status message
    public static String returnLoginStatus(boolean isSuccess) {
        return isSuccess ? 
            "Welcome " + savedFirstName + " " + savedLastName + ", it is great to see you again." : 
            "Username or password incorrect, please try again.";
    }

    // 7. Reset method for testing
    public static void reset() {
        savedUsername = null;
        savedPassword = null;
        savedFirstName = "Kyle";
        savedLastName = "Smith";
    }
}
