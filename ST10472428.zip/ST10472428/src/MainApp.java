/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author jeyhlin
 */
import javax.swing.JOptionPane;

public class MainApp {
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat Login");

        // Prompt user for registration input
        String username = JOptionPane.showInputDialog("Enter a username (e.g., ky1_1):");
        String password = JOptionPane.showInputDialog("Enter a password (e.g., Ch&&sec@ke99!):");
        String phone = JOptionPane.showInputDialog("Enter your cell number (e.g., +27831234567):");

        // Register user
        String registrationResult = Login.registerUser(username, password, phone);
        JOptionPane.showMessageDialog(null, registrationResult);

        if (!registrationResult.contains("successfully")) {
            JOptionPane.showMessageDialog(null, "Registration failed. Exiting...");
            System.exit(0);
        }

        //  login
        String loginUsername = JOptionPane.showInputDialog("Login - Enter your username:");
        String loginPassword = JOptionPane.showInputDialog("Login - Enter your password:");

        boolean loginSuccess = Login.loginUser(loginUsername, loginPassword);
        String loginMessage = Login.returnLoginStatus(loginSuccess);
        JOptionPane.showMessageDialog(null, loginMessage);

        if (loginSuccess) {
            MessageSystem.runMessageSystem();
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting...");
            System.exit(0);
        }
    }
}

