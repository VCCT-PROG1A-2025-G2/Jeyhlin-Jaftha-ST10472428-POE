import javax.swing.*;

public class MessageSystem {

    public static void main(String[] args) {
        Message.loadStoredMessagesFromJSON(); 
        showWelcomeMessage();
        int numberOfMessages = askHowManyMessages();

        for (int i = 0; i < numberOfMessages; i++) {
            processSingleMessage(i + 1);
        }

        showTotalMessages();
        showPostProcessingMenu();  // 
    }

    private static void showWelcomeMessage() {
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat");
    }

    private static int askHowManyMessages() {
        while (true) {
            String input = JOptionPane.showInputDialog("How many messages would you like to send?");
            if (input == null) {
                JOptionPane.showMessageDialog(null, "Session cancelled.");
                System.exit(0);
            }
            try {
                int count = Integer.parseInt(input);
                if (count > 0) return count;
            } catch (NumberFormatException e) {}
            JOptionPane.showMessageDialog(null, "Please enter a valid positive number.");
        }
    }

    private static void processSingleMessage(int messageNumber) {
        JOptionPane.showMessageDialog(null, "Message " + messageNumber + " of your batch");

        String recipient = promptPhoneNumber();
        if (recipient == null) cancelFlow();

        String messageText = promptMessage();
        if (messageText == null) cancelFlow();

        Message msg = new Message(recipient, messageText);

        if (!validateMessageLength(msg)) return;
        if (!validatePhoneNumber(msg)) return;

        showMessageDetails(msg);
        int choice = getUserAction();
        handleUserAction(choice, msg);
    }

    private static String promptPhoneNumber() {
        return JOptionPane.showInputDialog("Enter recipient phone number (e.g., +27831234567):");
    }

    private static String promptMessage() {
        return JOptionPane.showInputDialog("Enter your message (max 250 characters):");
    }

    private static boolean validateMessageLength(Message msg) {
        if (!msg.isMessageLengthValid()) {
            JOptionPane.showMessageDialog(null, msg.validateMessageLength());
            return false;
        }
        return true;
    }

    private static boolean validatePhoneNumber(Message msg) {
        if (!msg.checkRecipientCell()) {
            JOptionPane.showMessageDialog(null, msg.validateRecipientNumber());
            return false;
        }
        return true;
    }

    private static void showMessageDetails(Message msg) {
        JOptionPane.showMessageDialog(null,
                "Message ID: " + msg.getMessageID() + "\nHash: " + msg.getMessageHash());
    }

    private static int getUserAction() {
        String[] options = {"Send", "Store", "Disregard"};
        return JOptionPane.showOptionDialog(null, "What would you like to do with this message?",
                "Message Options", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                null, options, options[0]);
    }

    private static void handleUserAction(int choice, Message msg) {
        switch (choice) {
            case 0:
                msg.sendMessage();
                JOptionPane.showMessageDialog(null, "Message sent!");
                break;
            case 1:
                msg.storeMessage();
                JOptionPane.showMessageDialog(null, "Message stored.");
                break;
            case 2:
                msg.disregardMessage();
                JOptionPane.showMessageDialog(null, "Message disregarded.");
                break;
            default:
                JOptionPane.showMessageDialog(null, "No action taken.");
        }
    }

    private static void showTotalMessages() {
        int total = Message.returnTotalMessages();
        JOptionPane.showMessageDialog(null, "Total messages sent: " + total);
    }

    private static void cancelFlow() {
        JOptionPane.showMessageDialog(null, "Message cancelled.");
        System.exit(0);
    }

  
    private static void showPostProcessingMenu() {
        while (true) {
            String[] options = {
                    "Display all senders & recipients",
                    "Show longest message",
                    "Search by Message ID",
                    "Search by Recipient",
                    "Delete Message by Hash",
                    "Show Message Report",
                    "Exit"
            };

            int choice = JOptionPane.showOptionDialog(null,
                    "Choose a report or action:",
                    "Message Reports & Tools",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[0]);

            switch (choice) {
                case 0 -> Message.displayAllSendersAndRecipients();
                case 1 -> Message.displayLongestMessage();
                case 2 -> {
                    String id = JOptionPane.showInputDialog("Enter message ID to search:");
                    if (id != null) Message.searchMessageByID(id);
                }
                case 3 -> {
                    String recipient = JOptionPane.showInputDialog("Enter recipient number to search:");
                    if (recipient != null) Message.searchMessagesByRecipient(recipient);
                }
                case 4 -> {
                    String hash = JOptionPane.showInputDialog("Enter message hash to delete:");
                    if (hash != null) Message.deleteMessageByHash(hash);
                }
                case 5 -> Message.displayMessageReport();
                case 6 -> {
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                    System.exit(0);
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid option.");
            }
        }
    }

    static void runMessageSystem() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

