import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.*;

public class Message {
    private static int messageCount = 0;
    private static int totalSentMessages = 0;

    // Static lists 
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> disregardedMessages = new ArrayList<>();
    private static final List<Message> storedMessages = new ArrayList<>();
    private static final List<String> messageHashes = new ArrayList<>();
    private static final List<String> messageIDs = new ArrayList<>();

    // Instance variables
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String message;
    private String messageHash;

    // Constructor
    public Message(String recipient, String message) {
        this.messageID = generateMessageID();
        this.messageNumber = messageCount++;
        this.recipient = recipient;
        this.message = message;
        this.messageHash = createMessageHash();
    }

    // Generate random 10-digit ID
    public String generateMessageID() {
        Random random = new Random();
        return String.format("%010d", random.nextInt(1_000_000_000));
    }

    public boolean checkMessageID() {
        return this.messageID.length() == 10;
    }

    public boolean checkRecipientCell() {
        return recipient.startsWith("+27") && recipient.length() >= 12;
    }

    public String createMessageHash() {
        String[] words = message.trim().split("\\s+");
        if (words.length == 0) {
            return messageID.substring(0, 2) + ":" + messageNumber + ":EMPTY";
        }

        String firstWord = words[0].toUpperCase();
        String lastWord = words[words.length - 1].toUpperCase();
        return messageID.substring(0, 2) + ":" + messageNumber + ":" + firstWord + lastWord;
    }

    // Called when user chooses to send
    public String sendMessage() {
        totalSentMessages++;
        sentMessages.add(this);
        messageHashes.add(this.messageHash);
        messageIDs.add(this.messageID);
        return "Message successfully sent.";
    }

    public void storeMessage() {
    storedMessages.add(this);
    Gson gson = new GsonBuilder().setPrettyPrinting().create();
    try (FileWriter writer = new FileWriter("storedMessages.json")) {
        gson.toJson(storedMessages, writer);  // ✅ Writes entire array
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    // Called when user chooses to disregard
    public void disregardMessage() {
        disregardedMessages.add(this);
    }

    // Display message info (used in console or JOptionPane)
    public String printMessage() {
        return "Message ID: " + messageID +
                "\nMessage Hash: " + messageHash +
                "\nRecipient: " + recipient +
                "\nMessage: " + message;
    }

    // Used by test class
    public static int returnTotalMessages() {
        return totalSentMessages;
    }

    public boolean isMessageLengthValid() {
        return message.length() <= 250;
    }

    public String validateMessageLength() {
        int length = message.length();
        if (length <= 250) {
            return "Message ready to send.";
        } else {
            int excess = length - 250;
            return "Message exceeds 250 characters by " + excess + ", please reduce size.";
        }
    }

    public String validateRecipientNumber() {
        if (checkRecipientCell()) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }

    // Getters needed by tests
    public String getMessageID() {
        return messageID;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessage() {
        return message;
    }

    public String getMessageHash() {
        return messageHash;
    }


    // Load stored messages from JSON (ChatGPT-attributed)
    public static void loadStoredMessagesFromJSON() {
        // Source: OpenAI ChatGPT, 2025, response for loading JSON into List<Message>
        Gson gson = new Gson();
        try (FileReader reader = new FileReader("storedMessages.json")) {
            Type listType = new TypeToken<ArrayList<Message>>() {}.getType();
            List<Message> loaded = gson.fromJson(reader, listType);
            if (loaded != null) {
                storedMessages.clear();
                storedMessages.addAll(loaded);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Report: all senders/recipients
    public static void displayAllSendersAndRecipients() {
        System.out.println("Senders & Recipients:");
        for (Message m : sentMessages) {
            System.out.println("To: " + m.recipient);
        }
    }

    // Report: longest message
    public static void displayLongestMessage() {
        Message longest = null;
        for (Message m : sentMessages) {
            if (longest == null || m.message.length() > longest.message.length()) {
                longest = m;
            }
        }
        if (longest != null) {
            System.out.println("Longest Message: " + longest.message);
        }
    }

    // Search by ID
    public static void searchMessageByID(String id) {
        for (Message m : sentMessages) {
            if (m.messageID.equals(id)) {
                System.out.println("Found Message: " + m.message);
                System.out.println("Recipient: " + m.recipient);
                return;
            }
        }
        System.out.println("Message ID not found.");
    }

    // Search by recipient
    public static void searchMessagesByRecipient(String number) {
        for (Message m : sentMessages) {
            if (m.recipient.equals(number)) {
                System.out.println("Message: " + m.message);
            }
        }
    }

    // Delete message using message hash
    public static void deleteMessageByHash(String hash) {
        Iterator<Message> iterator = sentMessages.iterator();
        while (iterator.hasNext()) {
            Message m = iterator.next();
            if (m.messageHash.equals(hash)) {
                iterator.remove();
                System.out.println("Message \"" + m.message + "\" successfully deleted.");
                return;
            }
        }
        System.out.println("Message hash not found.");
    }

    // Full report
    public static void displayMessageReport() {
        System.out.println("==== SENT MESSAGE REPORT ====");
        for (Message m : sentMessages) {
            System.out.println("Message Hash: " + m.messageHash);
            System.out.println("Recipient: " + m.recipient);
            System.out.println("Message: " + m.message);
            System.out.println("----------------------------");
        }
    }
}
