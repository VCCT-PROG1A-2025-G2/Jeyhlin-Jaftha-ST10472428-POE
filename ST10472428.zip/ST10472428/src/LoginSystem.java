/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author jeyhl
 */
public class LoginSystem {
    public static void main(String[] args) {
       String username = "ky1_1"; 
       String password = "Ch&&sec@ke99!";      
String phone = "+27838968960";   

        // Register user
        String registrationResult = Login.registerUser(username, password, phone);
        System.out.println(registrationResult);

        // Attempt login
        boolean loginSuccess = Login.loginUser(username, password);
        String loginMessage = Login.returnLoginStatus(loginSuccess);
        System.out.println(loginMessage);
    }
}
