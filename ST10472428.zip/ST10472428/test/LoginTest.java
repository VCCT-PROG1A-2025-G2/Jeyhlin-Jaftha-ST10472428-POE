import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class LoginTest {

    @Before
    public void setup() {
        Login.reset();  // Ensure we start with fresh data
    }

    // Username Format Tests
    @Test
    public void testCorrectUsernameFormat() {
        assertTrue(Login.checkUserName("kyl_1"));
    }

    @Test
    public void testIncorrectUsernameFormat() {
        assertFalse(Login.checkUserName("kyle!!!!!!!"));
    }

    // Password Complexity Tests
    @Test
    public void testCorrectPasswordComplexity() {
        assertTrue(Login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }

    @Test
    public void testIncorrectPasswordComplexity() {
        assertFalse(Login.checkPasswordComplexity("password"));
    }

    // Cell Phone Number Validation Tests
    @Test
    public void testCorrectCellPhoneNumberFormat() {
        assertTrue(Login.checkCellPhoneNumber("+27838968976"));
    }

    @Test
    public void testIncorrectCellPhoneNumberFormat() {
        assertFalse(Login.checkCellPhoneNumber("08966553"));
    }

    // Register User Tests
    @Test
    public void testRegisterUser_AllCorrect() {
        String result = Login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("Account successfully registered.", result);
    }

    @Test
    public void testRegisterUser_IncorrectUsername() {
        String result = Login.registerUser("kyle123", "Ch&&sec@ke99!", "+27838968976");
        assertEquals("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.", result);
    }

    @Test
    public void testRegisterUser_IncorrectPassword() {
        String result = Login.registerUser("kyl_1", "password", "+27838968976");
        assertEquals("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.", result);
    }

    @Test
    public void testRegisterUser_IncorrectPhone() {
        String result = Login.registerUser("kyl_1", "Ch&&sec@ke99!", "08966553");
        assertEquals("Cell number is incorrectly formatted or does not contain an international code, please correct the number and try again.", result);
    }

    // Login Status Tests
    @Test
    public void testLoginSuccess() {
        Login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        // Try logging in with correct credentials
        boolean success = Login.loginUser("kyl_1", "Ch&&sec@ke99!");
        String loginStatus = Login.returnLoginStatus(success);

        assertEquals("Welcome Kyle Smith, it is great to see you again.", loginStatus);
    }

    @Test
    public void testLoginFailure() {
        Login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        // Try logging in with incorrect credentials
        boolean success = Login.loginUser("kyl_1", "WrongPassword!");
        String loginStatus = Login.returnLoginStatus(success);

        assertEquals("Username or password incorrect, please try again.", loginStatus);
    }

    @Test
    public void testLoginStatusSuccess() {
        Login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        // Login with correct credentials
        boolean success = Login.loginUser("kyl_1", "Ch&&sec@ke99!");
        String status = Login.returnLoginStatus(success);

        assertEquals("Welcome Kyle Smith, it is great to see you again.", status);
    }

    @Test
    public void testLoginStatusFail() {
        Login.registerUser("kyl_1", "Ch&&sec@ke99!", "+27838968976");

        // Login with incorrect credentials
        boolean success = Login.loginUser("wrong", "wrong");
        String status = Login.returnLoginStatus(success);

        assertEquals("Username or password incorrect, please try again.", status);
    }
}

