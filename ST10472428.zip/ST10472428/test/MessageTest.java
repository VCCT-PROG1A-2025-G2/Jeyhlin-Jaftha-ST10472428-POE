import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class MessageTest {

    private Message validMessage1;
    private Message validMessage2;
    private Message longMessage;
    private Message invalidNumberMessage;

    @Before
    public void setup() {
        validMessage1 = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight");
        validMessage2 = new Message("+27831234567", "Hi Keegan, did you receive the payment?");
        longMessage = new Message("+27718693002", "a".repeat(260));
        invalidNumberMessage = new Message("08575975889", "This is a test message");
    }

    // Message Length Validation

    @Test
    public void testMessageLengthSuccess() {
        assertTrue(validMessage1.isMessageLengthValid());
    }

    @Test
    public void testMessageLengthFailure() {
        assertFalse(longMessage.isMessageLengthValid());
    }

    //  Recipient Number Validation

    @Test
    public void testValidRecipientNumber() {
        assertTrue(validMessage1.checkRecipientCell());
    }

    @Test
    public void testInvalidRecipientNumber() {
        assertFalse(invalidNumberMessage.checkRecipientCell());
    }

    // Message Hash Format

    @Test
    public void testMessageHashCorrect() {
        String hash = validMessage1.createMessageHash();
        assertNotNull(hash);
        assertTrue(hash.matches("\\d{2}:\\d+:\\w+\\w+"));
    }

    //  Message ID Format

    @Test
    public void testMessageIDIsCorrectLength() {
        assertEquals(10, validMessage1.getMessageID().length());
    }

    //  Send Counter Increments

    @Test
    public void testSendMessageUpdatesCounter() {
        int before = Message.returnTotalMessages();
        validMessage1.sendMessage();
        int after = Message.returnTotalMessages();
        assertEquals(before + 1, after);
    }

    //  Total Message Count

    @Test
    public void testTotalMessagesCountIncreases() {
        int countBefore = Message.returnTotalMessages();
        validMessage1.sendMessage();
        validMessage2.sendMessage();
        assertEquals(countBefore + 2, Message.returnTotalMessages());
    }

    // Search By Message ID 
    @Test
    public void testSearchByID() {
        validMessage1.sendMessage();
        System.out.println("🔍 Search by ID:");
        Message.searchMessageByID(validMessage1.getMessageID()); 
    }

    // Search by Recipient (Console output)

    @Test
    public void testSearchByRecipient() {
        validMessage2.sendMessage();
        System.out.println("🔍 Search by Recipient:");
        Message.searchMessagesByRecipient(validMessage2.getRecipient()); 
    }

    

    @Test
    public void testDeleteByHash() {
        Message temp = new Message("+27831230000", "Test delete by hash");
        temp.sendMessage();
        String hash = temp.getMessageHash();
        System.out.println("🗑️ Delete test for hash: " + hash);
        Message.deleteMessageByHash(hash); 
    }

    // Display Sent Message Report

    @Test
    public void testDisplayMessageReport() {
        System.out.println("Final Message Report:");
        Message.displayMessageReport(); 
    }

    // Load Stored Messages from JSON
@Test
public void testLoadStoredMessagesFromJSON() {
    validMessage1.storeMessage(); 
    Message.loadStoredMessagesFromJSON();
    System.out.println("Loaded stored messages successfully.");
}
}
   
   
   
   

